# Create your views here.
# This File Created by Akshay
from django.http import HttpResponse
from django.shortcuts import render, redirect
import random
import datetime


def index(request):
    try:
        if request.method == "POST":
            SAL = request.POST["OPT"]
            NM1 = request.POST["CUST_NAME"]
            NM2 = request.POST["WIT_NAME"]
            IMG_ID = request.POST["PHOTO_URL"]
            # USER_IMG = request.FILES['USER_IMG']
            DATE = datetime.date.today().strftime('%d/%m/%Y')
            TODAY = datetime.date.today().strftime('%Y%m%d')[2:]
            QR1 = random.randint(10000000, 90000000)
            QR2 = random.randint(10000000000000000, 90000000000000000)
            string = '1268' + TODAY + '10' + str(QR1)
            string2 ='21499'+str(QR2)
            data = {"SAL":SAL,"QR1":string,"QR2":string2,"NAME":NM1,"NA":NM2,"IMG_ID":IMG_ID,'DATE':DATE}
            return render(request,'demo.html',data)
        return render(request,'Index.html')

    except Exception as e:
        print(e)